package com.demo.TestNGProject;

import org.testng.annotations.Test;

public class Assignment_2E extends Base_Test {
@Test
public void wikipedia() throws InterruptedException {
	driver.get("https://www.wikipedia.org/");
	Thread.sleep(3000);
	Assignment_2P wiki= new Assignment_2P(driver);
	Thread.sleep(3000);
	wiki.getSt();
	Thread.sleep(2000);
	wiki.scroll();
	Thread.sleep(2000);
	wiki.privacyC();
	System.out.println("Script Run successfully");
}
}
