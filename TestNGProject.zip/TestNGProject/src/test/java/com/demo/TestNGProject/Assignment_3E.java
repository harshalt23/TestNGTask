package com.demo.TestNGProject;

import org.testng.annotations.Test;

public class Assignment_3E extends Base_Test{
@Test
	public void Amezon() throws InterruptedException {
		driver.get("https://www.amazon.in/");
		Assignment_3P amez=new Assignment_3P(driver);
		Thread.sleep(3000);
		amez.button();
		Thread.sleep(3000);
		amez.searchbox();
		Thread.sleep(2000);
		amez.clicking();
		Thread.sleep(2000);
		scroll();
		Thread.sleep(2000);
		amez.clickingtwce();
		System.out.println("Script Run Successfully");
		
	}
}
