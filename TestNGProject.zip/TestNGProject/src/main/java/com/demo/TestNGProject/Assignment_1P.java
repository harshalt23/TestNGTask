package com.demo.TestNGProject;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Assignment_1P {

 private WebDriver driver;
 
 Assignment_1P(WebDriver driver){
	 this.driver=driver;
	 }
 
	// Locators
private	By userName= By.name("username");
private	By password=By.name("password");
private	By click_log=By.className("orangehrm-login-button");
private By tagging =By.tagName("i");

	//Actions
	public void enterUserName() {
		driver.findElement(userName).sendKeys("Admin");
		
	}
	public void enterPass() {
		driver.findElement(password).sendKeys("Admin@123");
	}
	
	public void log_in() {
		driver.findElement(click_log).click();
	}
	public List<WebElement> GetAlltags() {
		return driver.findElements(tagging);
	}
 }

