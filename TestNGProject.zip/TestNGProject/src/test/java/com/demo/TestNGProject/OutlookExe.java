package com.demo.TestNGProject;

import java.time.Duration;
import java.util.Properties;
import utils.ConfigReader;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import com.demo.TestNGProject.outlook.LoginPage;

public class OutlookExe {
    public WebDriver driver;

    @Test
    public void invokeBrowser() throws InterruptedException {
        
        Properties prop = ConfigReader.initProperties();

        String uname = prop.getProperty("username");
        String pwd   = prop.getProperty("password");

        System.setProperty("webdriver.edge.driver",
                "C:\\Users\\Harshal.Tandulkar\\eclipse-workspace\\TestNGProject\\Drivers\\msedgedriver.exe");

        EdgeOptions option = new EdgeOptions();
        option.addArguments("InPrivate");
        driver = new EdgeDriver(option);

        driver.get("https://outlook.office.com/");
        driver.manage().window().maximize();
        Thread.sleep(3000);

        LoginPage log = new LoginPage(driver);
        Thread.sleep(3000);
        log.userName(uname);
        Thread.sleep(3000);
        log.nextButton();
        Thread.sleep(3000);
        log.passwordF(pwd);
        Thread.sleep(5000);
        log.NextButton();
        Thread.sleep(3000);
        JavascriptExecutor j=(JavascriptExecutor)driver;
    	j.executeScript("window.scrollBy(0,500)");
    	
        log.staySignIn();
       Thread.sleep(4000);
     
      
       
    }

	
	}

