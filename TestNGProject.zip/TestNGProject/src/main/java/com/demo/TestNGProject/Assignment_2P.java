package com.demo.TestNGProject;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Assignment_2P {
private WebDriver driver;

Assignment_2P(WebDriver driver){
	this.driver=driver;
}

//locators
private By stId=By.id("js-link-box-en");
private By privacy=By.partialLinkText("Privacy ");

//Actions
public void getSt() {
	WebElement stText=driver.findElement(stId);
	String  linkTextt=stText.getText();
	WebElement newText=driver.findElement(By.linkText(linkTextt));
	newText.click();
}

public void privacyC() {
	driver.findElement(privacy).click();
}
public void scroll() {
		JavascriptExecutor j=(JavascriptExecutor)driver;
	j.executeScript("window.scrollBy(0,500)");
}
}
