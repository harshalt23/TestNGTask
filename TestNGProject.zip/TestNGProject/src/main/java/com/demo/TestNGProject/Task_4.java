package com.demo.TestNGProject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

public class Task_4 {
public WebDriver driver;
	@BeforeSuite
	public void invokebrowser() {
	     System.setProperty("webdriver.edge.driver",
	                "C:\\Users\\Harshal.Tandulkar\\eclipse-workspace\\TestNGProject\\Drivers\\msedgedriver.exe");
//
//	        driver=new EdgeDriver();
//	        driver.manage().window().maximize();
//	        System.out.println("Browser Invoked Successfully");
	        EdgeOptions option=new EdgeOptions();
	        option.addArguments("InPrivate");
	        driver=new EdgeDriver(option);
	}
	
	@BeforeMethod
	public void openUrl() throws InterruptedException {
		driver.get("https://www.amazon.in/");
		Thread.sleep(3000);
	}
	@Test
	public void getTitle() {
		String title=driver.getTitle();
		System.out.println(title);
		Assert.assertTrue(title.contains("Amazon"),"Title is not found "+title);
		System.out.println("Title found successfully");
	}
	@AfterMethod
	public void printmessage() {
		System.out.println("After method use successfully");
	}
	@AfterSuite
	public void teardown() {
		if(driver!=null) {
			driver.quit();
		}
	}
}
