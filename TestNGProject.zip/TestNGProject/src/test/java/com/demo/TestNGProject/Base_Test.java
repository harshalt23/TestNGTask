package com.demo.TestNGProject;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

public class Base_Test {

    public static WebDriver driver;
    

    @BeforeClass
    public void setup() {
        System.setProperty("webdriver.edge.driver",
                "C:\\Users\\Harshal.Tandulkar\\eclipse-workspace\\TestNGProject\\Drivers\\msedgedriver.exe");

        driver=new EdgeDriver();
        driver.manage().window().maximize();
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
    public void scroll() {
		JavascriptExecutor j=(JavascriptExecutor)driver;
	j.executeScript("window.scrollBy(0,500)");
}
}
