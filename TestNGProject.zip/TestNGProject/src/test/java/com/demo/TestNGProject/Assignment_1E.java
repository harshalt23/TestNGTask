package com.demo.TestNGProject;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class Assignment_1E extends Base_Test {
	@Test
	public void OrangeHrm() throws InterruptedException {
		driver.get("https://opensource-demo.orangehrmlive.com/");
		Assignment_1P ohrm =new Assignment_1P(driver);
		Thread.sleep(5000);
		ohrm.enterUserName();
		Thread.sleep(4000);
		ohrm.enterPass();
		Thread.sleep(2000);
		ohrm.log_in();
		List<WebElement>icon=ohrm.GetAlltags();
		System.out.println("Number of tags"+icon.size());
		for(WebElement totalI:icon) {
			System.out.println(totalI.getText());
			
		}
	}
	

}
