package com.demo.TestNGProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Assignment_3P {
private WebDriver driver;

Assignment_3P(WebDriver driver){
	this.driver=driver;
}

private By button=By.className("a-button-text");
private By searchBox=By.cssSelector("#twotabsearchtextbox");
private By cliking=By.cssSelector("input[value='Go']");
private By clicking2=By.cssSelector("div.s-main-slot > div[data-component-type='s-search-result']:nth-child(9) a");


public void button() {
	driver.findElement(button).click();

}
public void searchbox() {
	driver.findElement(searchBox).sendKeys("Laptop");
}
public void clicking() {
	driver.findElement(cliking).click();
}
public void clickingtwce() {
	driver.findElement(clicking2).click();;
}

}
