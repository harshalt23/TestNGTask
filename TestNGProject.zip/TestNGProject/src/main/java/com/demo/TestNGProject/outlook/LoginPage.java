package com.demo.TestNGProject.outlook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


public class LoginPage {

	private WebDriver driver;
	
	public LoginPage(WebDriver driver){
		this.driver=driver;
	}
	public LoginPage() {
		
	}
	
	private By userName= By.xpath("//input[@id='i0116']");
	private By nextButton=By.xpath("//input[@id='idSIButton9']");
	private By passwordF=By.xpath("//input[@Name='passwd']");
	private By NextButton=By.cssSelector("#view > div > div.___1hpzav7.f22iagw.f1vx9l62.f1noh358.fyym0d2 > button");
	private By staysignIn=By.xpath("//*[@id='view']/div/div[5]/button[1]");
	//*[@id="view"]/div/div[5]/button[1]
	
	public void userName(String uname) {
		driver.findElement(userName).sendKeys(uname);
	}
	public void nextButton() {
		driver.findElement(nextButton).click();
	}
	public void passwordF( String pwd) {
		driver.findElement(passwordF).sendKeys(pwd);
	}
	public void NextButton() {
		driver.findElement(NextButton).click();;
		
	}
	public void staySignIn() {
	driver.findElement(staysignIn).click();
	}
	
	
	
}
