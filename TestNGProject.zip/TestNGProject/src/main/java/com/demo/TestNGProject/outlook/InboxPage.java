package com.demo.TestNGProject.outlook;

public class InboxPage {

}
